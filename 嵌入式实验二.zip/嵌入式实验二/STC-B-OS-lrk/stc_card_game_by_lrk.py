# stc_card_game_by_lrk.py
import serial
import time
import random
import sys
import logging
import threading
import tkinter as tk
from tkinter import scrolledtext

# 配置（需要时可改）
SERVER_PORT = 'COM3'
PLAYER1_PORT = 'COM4'
PLAYER2_PORT = 'COM7'
BAUDRATE = 115200
POLL_INTERVAL = 0.001  # 1 ms

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')


def open_serial(port):
    try:
        # 使用略微非阻塞的短超时，写入也设置超时，便于发现阻塞或异常
        ser = serial.Serial(port, BAUDRATE, timeout=0.01, write_timeout=0.1)
        logging.info(f'Opened serial {port} @ {BAUDRATE}')
        return ser
    except Exception as e:
        logging.error(f'Failed to open {port}: {e}')
        sys.exit(1)


def decode_server_byte(b):
    # b: int 0-255
    winner = b & 0x03
    next_flag = (b & 0x04) >> 2
    state = (b & 0x08) >> 3
    return winner, next_flag, state


def make_player_byte(player_bit, poker_value):
    # player_bit: 0x01 (player1) or 0x02 (player2)
    # poker_value: 1..13
    # PLAYER 格式: lower 2 bits = player, bits2..5 = poker
    val = ((poker_value & 0x0F) << 2) & 0x3C
    val |= (player_bit & 0x03)
    return val & 0xFF


# 可视化 GUI 类
class CardGUI:
    def __init__(self, stop_event=None):
        self.stop_event = stop_event
        self.root = tk.Tk()
        self.root.title('发牌')
        self.root.geometry('420x300')

        frm = tk.Frame(self.root)
        frm.pack(fill='both', expand=True, padx=8, pady=8)

        self.lbl_p1 = tk.Label(frm, text='Player1: -', font=('Arial', 12))
        self.lbl_p1.grid(row=0, column=0, sticky='w')
        self.lbl_p2 = tk.Label(frm, text='Player2: -', font=('Arial', 12))
        self.lbl_p2.grid(row=1, column=0, sticky='w')

        self.lbl_deck = tk.Label(frm, text='Deck remaining: 0', font=('Arial', 10))
        self.lbl_deck.grid(row=2, column=0, sticky='w', pady=(8,0))

        self.log = scrolledtext.ScrolledText(frm, height=10, state='disabled', wrap='word')
        self.log.grid(row=3, column=0, columnspan=2, sticky='nsew', pady=(6,0))

        frm.rowconfigure(3, weight=1)
        frm.columnconfigure(1, weight=1)

    def _safe_call(self, fn, *a, **kw):
        # 在 GUI 线程中执行更新
        try:
            self.root.after(0, lambda: fn(*a, **kw))
        except Exception:
            pass

    def show_dealt(self, player_idx, poker_value):
        def _update():
            txt = f'{poker_value}'
            if player_idx == 0:
                self.lbl_p1.config(text=f'Player1: {txt}')
            else:
                self.lbl_p2.config(text=f'Player2: {txt}')
            self._append_log(f'Dealt to Player{player_idx+1}: {poker_value}')

        self._safe_call(_update)

    def update_deck(self, count):
        self._safe_call(lambda: self.lbl_deck.config(text=f'Deck remaining: {count}'))

    def _append_log(self, msg):
        self.log.config(state='normal')
        self.log.insert('end', msg + '\n')
        self.log.see('end')
        self.log.config(state='disabled')

    def log_msg(self, msg):
        self._safe_call(self._append_log, msg)


# 将原来的 main() 中串口 / 发牌逻辑抽取到后台运行函数
def run_game(gui=None, stop_event=None):
    ser_server = open_serial(SERVER_PORT)
    ser_p1 = open_serial(PLAYER1_PORT)
    ser_p2 = open_serial(PLAYER2_PORT)

    # 打开后短暂等待并清空缓冲，避免读取到连接建立前或之前残留的数据
    time.sleep(0.05)
    try:
        ser_server.reset_input_buffer()
        ser_server.reset_output_buffer()
        ser_p1.reset_input_buffer()
        ser_p1.reset_output_buffer()
        ser_p2.reset_input_buffer()
        ser_p2.reset_output_buffer()
        logging.info('Serial buffers cleared after open.')
    except AttributeError:
        logging.warning('reset_input/output_buffer not supported on this pyserial version')

    players = [
        {'name': 'Player1', 'ser': ser_p1, 'bit': 0x01},
        {'name': 'Player2', 'ser': ser_p2, 'bit': 0x02},
    ]

    deck = [v for v in range(1, 14) for _ in range(4)]
    random.shuffle(deck)
    logging.info(f'Deck prepared: {len(deck)} cards')
    if gui:
        gui.update_deck(len(deck))
        gui.log_msg('Deck prepared')

    try:
        logging.info('Waiting for server to start game (state=1)...')
        game_started = False
        while True:
            if stop_event and stop_event.is_set():
                logging.info('Stop event set before game start. Exiting run_game.')
                return
            b = ser_server.read(1)
            if b:
                byte = b[0]
                winner, next_flag, state = decode_server_byte(byte)
                logging.info(f'Recv server init byte: {byte:02X} -> winner={winner}, next={next_flag}, state={state}')
                if gui:
                    gui.log_msg(f'Recv server init: {byte:02X} -> winner={winner}, next={next_flag}, state={state}')
                if state == 1:
                    logging.info('Game started by server.')
                    game_started = True
                    break
            time.sleep(POLL_INTERVAL)

        current_player_idx = 0

        while True:
            if stop_event and stop_event.is_set():
                logging.info('Stop event set. Exiting run_game loop.')
                break

            if not deck:
                logging.warning('No more cards in deck. Stopping.')
                if gui:
                    gui.log_msg('No more cards in deck. Stopping.')
                break

            player = players[current_player_idx]
            poker = deck.pop()
            player_byte = make_player_byte(player['bit'], poker)

            try:
                written = player['ser'].write(bytes([player_byte]))
                try:
                    player['ser'].flush()
                except Exception:
                    logging.debug('flush() failed or unsupported for player serial')
                logging.info(f"Sent to {player['name']}: PLAYER=0x{player_byte:02X} (poker={poker}), bytes_written={written}")
                if gui:
                    gui.show_dealt(current_player_idx, poker)
                    gui.update_deck(len(deck))
            except Exception as e:
                logging.error(f"Failed to write to {player['name']} on serial: {e}")
                if gui:
                    gui.log_msg(f'Error sending to {player["name"]}: {e}')

            last_logged_byte = None
            while True:
                if stop_event and stop_event.is_set():
                    logging.info('Stop event set inside wait loop. Exiting.')
                    break
                b = ser_server.read(1)
                if b:
                    byte = b[0]
                    if byte != last_logged_byte:
                        winner, next_flag, state = decode_server_byte(byte)
                        logging.info(f'Recv server byte: {byte:02X} -> winner={winner}, next={next_flag}, state={state}')
                        if gui:
                            gui.log_msg(f'Server: {byte:02X} -> winner={winner}, next={next_flag}, state={state}')
                        last_logged_byte = byte
                    else:
                        winner, next_flag, state = decode_server_byte(byte)

                    # state == 0 表示游戏结束（不再发牌）
                    if state == 0:
                        logging.info('Server indicated game end (state=0). Exiting.')
                        if gui:
                            gui.log_msg('Server indicated game end (state=0). Exiting.')
                        return

                    # next == 1 表示前一轮结束，进入下一轮
                    if next_flag == 1:
                        current_player_idx = 1 - current_player_idx
                        logging.info('Server indicated next round. Switching player and continue.')
                        if gui:
                            gui.log_msg('Next round')
                        break

                time.sleep(POLL_INTERVAL)

            if stop_event and stop_event.is_set():
                break

    except KeyboardInterrupt:
        logging.info('Interrupted by user.')
    finally:
        for s in (ser_server, ser_p1, ser_p2):
            try:
                s.close()
            except:
                pass
        logging.info('Serial ports closed. Program exit.')
        if gui:
            gui.log_msg('Serial ports closed. Program exit.')


# 主入口：创建 GUI，启动后台线程运行串口逻辑
def main():
    stop_event = threading.Event()
    gui = CardGUI(stop_event=stop_event)

    t = threading.Thread(target=run_game, args=(gui, stop_event), daemon=True)
    t.start()

    def on_close():
        stop_event.set()
        try:
            gui.root.destroy()
        except Exception:
            pass

    gui.root.protocol('WM_DELETE_WINDOW', on_close)
    gui.root.mainloop()


if __name__ == '__main__':
    main()