#include "rs485.h" // 包含 RS485 模块的头文件

void rs485_init(u32 baudrate) // 初始化 RS485 的函数，参数为波特率
{ // rs485_init 函数开始
    //Set TX/DR pins (P37, P47) to Push-Pull, RX pin (P46) to input.
    {
        P4M1 &= 0x3F;	// 0111 1111
        P4M0 |= 0xC0;   // 1000 0000

        P3M1 &= 0x7F;   // 0111 1111
        P3M0 |= 0x80;   // 1000 0000

        P4M1 |= 0x40;   // 0100 0000
        P4M0 &= 0xBF;   // 1011 1111
    } // GPIO 配置块结束

    //Configure baudrate timer
    {
        XDATA u16 reload = 65536 - ((MAIN_Fosc / 4) / baudrate);	//1T
                                // 计算定时器重装值以生成所需波特率
        AUXR &= ~(1<<4);	//Timer stop
                                // 停止定时器以便配置
        AUXR &= ~(1<<3);	//Timer2 set As Timer
                                // 将 Timer2 配置为定时器模式
        AUXR |=  (1<<2);	//Timer2 set as 1T mode
                                // 设置 Timer2 为 1T 模式
        IE2  &= ~(1<<2);	//Disable interrupt
                                // 禁用相关中断以安全配置定时器

        TH2 = (u8)(reload>>8); // 将重装值高字节写入 TH2
        TL2 = (u8)reload;      // 将重装值低字节写入 TL2
        AUXR |=  (1<<4);	//Timer run enable
                                // 启动定时器
    } // 波特率定时器配置结束

    //Initialize UART2 on P46 and P47
    {
        IP2 |=  1;  //High priority interrupt
                                // 提升 UART2 中断优先级
        S2CON &= ~(1<<7); //8bit mode
                                // 设置串口为 8 位模式
        S2CON |=  (1<<4); //Enable Rx
                                // 使能接收功能
        P_SW2 = (P_SW2 & ~1) | (1 & 0x01); //Select IO port P46/P47
                                // 选择 UART2 使用的 IO 口 P46/P47
        RS485_STATE = RS485_R; //Half duplex mode set to Rx
                                // 设置 RS485 半双工为接收模式
        IE2 |= 1; //Enable interrupt (wait for incoming data)
                                // 允许 UART2 中断以接收数据
    }
} // rs485_init 函数结束

//this function blocks current process until all data is sent
void __rs485_write(u8* buf, u8 len) // 以阻塞方式发送数据的函数，buf 指向数据，len 为长度（0 表示以 '\0' 结尾的字符串）
{ // __rs485_write 函数开始
    u8 i; // 发送时使用的循环变量
    //Tx enable.
    RS485_STATE = RS485_D; // 切换到驱动（发送）模式
    //Disable UART2 interrupt (Tx uses polling mode)
    IE2 &= ~1; // 禁用 UART2 中断，发送使用轮询

		if(len)
		{
			for(i=0;i<len;i++)
			{
					//clear TX end flag
					S2CON &= ~2; // 清除发送完成标志
					//feed byte into UART2 buffer
					S2BUF = buf[i]; // 将字节写入发送缓冲寄存器
					//spin until TX end flag is set (by hardware)
					while((S2CON & 2) == 0); // 等待硬件设置发送完成标志
			}
		}
		else
		{
			for(i=0;;i++)
			{
					//clear TX end flag
					S2CON &= ~2; // 清除发送完成标志
					//feed byte into UART2 buffer
					if(buf[i] == '\0') break; 	// 遇到字符串结束符则退出
					S2BUF = buf[i]; // 写入发送缓冲寄存器
					//spin until TX end flag is set (by hardware)
					while((S2CON & 2) == 0); // 等待发送完成
			}
		}
    //Tx disable.
    RS485_STATE = RS485_R; // 切换回接收模式

    //Enable UART2 interrupt
    //(Rx uses interrupt to trigger, but still runs in polling mode)
    S2CON &= ~1;   //Reset all flags
                                // 清除接收相关标志
    S2CON &= ~2; // 清除发送相关标志
    IE2 |= 1; // 重新启用 UART2 中断
                                // 恢复接收中断
}


XDATA u8 rs485_buf[128]; // 接收缓冲区，存放接收到的数据
XDATA u8 rs485_rxcnt; // 接收计数器，记录已接收字节数
XDATA u32 rs485_timeout; // 接收超时计数，用于决定接收结束
XDATA u8 rs485_evtstate = 0; // 事件状态标志，1 表示有完整数据到达

void rs485_interrupt (void) interrupt UART2_VECTOR // UART2 中断服务函数，用于接收数据
{ // 中断函数开始
	//Tx uses polling mode, INT source can only be RX

    //Disable UART2 interrupt
    //(Rx uses interrupt to trigger, but still runs in polling mode)
    IE2 &= ~1; // 在处理中先禁用 UART2 中断以避免重入

    rs485_rxcnt = 0; // 接收字节计数器清零
    while(1)
    {
        S2CON &= ~1; //Remove RX end flag.
                                // 清除接收完成标志
        rs485_buf[rs485_rxcnt++] = S2BUF; //Retrieve byte.
                                // 从接收缓冲寄存器读取一个字节到缓冲区

        //Spin until RX end flag is set (by hardware)
        rs485_timeout = 500;//You have to try out a proper value for specific baud and clock frequency settings
                                // 设置接收等待超时计数初值
        while((S2CON & 1)==0) 
        {
            if(--rs485_timeout == 0)
                goto RX_END; // 超时退出接收循环
        }
    }

    RX_END:; // 接收结束标签
    
    S2CON &= ~1;  //Reset all flags
                                // 清除接收完成标志
    S2CON &= ~2; // 清除发送完成标志
    IE2 |= 1; //Enable UART2 interrupt
                                // 重新使能 UART2 中断

    rs485_evtstate = 1; // 标记有一帧数据已接收完毕，等待主循环处理
} // 中断函数结束