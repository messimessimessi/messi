#include "global.h" // 包含全局定义与类型
#include "stack.h" // 包含进程栈相关声明
#include "xstack.h" // 包含扩展栈（xstack）相关声明
#include "scheduler.h" // 包含调度器相关函数声明
#include "bit_ops.h" // 包含位操作辅助宏
#include "timer0_isr.h" // 包含定时器0中断相关声明
#include "syscall.h" // 包含系统调用（软中断）相关声明
#include "semaphore.h" // 包含信号量接口声明
#include "events.h" // 包含事件相关宏与声明
#include "seg_led.h" // 包含数码管/LED 显示接口
#include "button.h" // 包含按键处理接口
#include "usbcom.h" // 包含 USB 串口通信接口
#include "rs485.h" // 包含 RS485 通信接口
#include "random.h" // 包含随机数产生接口

#define TIMESLICE_MS	1 // 时间片长度（毫秒）
#define T12RL		(65536 - MAIN_Fosc*TIMESLICE_MS/12/1000)  // 定时器重载值计算，用于12T模式
XDATA u8 character = 0; // XDATA 段：设备角色/字符标识，初始为0
XDATA u16 gametime = 0; // 游戏时间计数器（以某单位累加）
XDATA u16 waittime = 0; // 等待时间计数器（未使用或备用）
XDATA u8 turn = 1; // 当前轮次编号，初始为1
XDATA u8 allturn = 4; // 总轮数，默认为4
XDATA float player1 = 0.0; // 玩家1的得分（浮点）
XDATA float player2 = 0.0; // 玩家2的得分（浮点）
XDATA u8 poker_point = 0; // 当前牌点（备用或未使用）
XDATA u8 winner = 0; // 胜者编号（0表示未决）
XDATA unsigned char mypoker[8]; // 存放我的牌的缓冲区，长度8


void testproc(u16 param) large reentrant // 测试进程：基于定时器计数控制 LED 显示
{
	while(1)
	{
		if((timer0_cnt>>5) & BIT(param)) // 根据 timer0_cnt 的某个位决定显示
		{
			SETBIT(led_display_content, param); // 设置对应 LED 显示位
		}
		else
		{
			CLEARBIT(led_display_content, param); // 清除对应 LED 显示位
		}
	}
}

void testproc2(u16 param) large reentrant // 测试进程2：周期性翻转整个显示
{
	while(1)
	{
		proc_sleep(param); // 休眠 param 毫秒
		led_display_content = ~led_display_content; // 取反显示内容
	}
}

void testproc3(u16 param) large reentrant // 测试进程3：周期性异或低四位
{
	while(1)
	{
		proc_sleep(param); // 休眠 param 毫秒
		led_display_content ^= 0x0f; // 切换低4位显示
	}
}

void testproc4() large reentrant // 测试进程4：使用信号量在两段之间同步切换 LED
{
	while(1)
	{
		proc_sleep(500); // 休眠500单位
		sem_post(0); // 释放信号量0
		led_display_content |= 0x80; // 点亮第7位 LED
		sem_wait(0); // 等待信号量0
		led_display_content &= ~0x80; // 熄灭第7位 LED
	}
}

void testproc5() large reentrant // 测试进程5：初始化信号量并循环等待/释放
{
	sem_init(0,0); // 初始化信号量0，初始值0
	while(1)
	{
		sem_wait(0); // 等待信号量0
		led_display_content |= 0x40; // 点亮第6位 LED
		proc_sleep(500); // 休眠500单位
		sem_post(0); // 释放信号量0
		led_display_content &= ~0x40; // 熄灭第6位 LED
	}
}

void testproc6(u16 param) large reentrant // 测试进程6：按键与串口事件驱动显示与通信
{
	while(1)
	{
		proc_wait_evts(EVT_BTN1_DN); // 等待按钮1按下事件
		seg_set_str("HELLO   "); // 在数码管上显示字符串 HELLO
		usbcom_write("hello \0",0); // 通过 USB 发送字符串（注意末尾的 \0）
		proc_wait_evts(EVT_NAV_R); // 等待导航右事件
		seg_set_str("WORLD   "); // 显示 WORLD
		usbcom_write("world\r\n\0",0); // 通过 USB 发送带回车换行的字符串
		proc_wait_evts(EVT_UART1_RECV); // 等待 UART1 接收事件
		seg_set_str(usbcom_buf); // 将 USB 接收缓冲区内容显示到数码管
	}
}

void testproc7(u16 param) large reentrant // 测试进程7：在 UART2 或按键事件时更新数码管并通过 RS485 发送随机数
{
	while(1)
	{
		proc_wait_evts(EVT_UART2_RECV | EVT_BTN1_DN); // 等待 UART2 接收或按钮1按下
		if(MY_EVENTS & EVT_BTN1_DN) // 如果事件是按钮按下
		{
			*((u32 *)rs485_buf) = rand32(); // 将32位随机数写入 RS485 缓冲区
			rs485_write(rs485_buf, 4); // 通过 RS485 发送4字节随机数
			seg_set_number(*((u32 *)rs485_buf)); // 在数码管显示该随机数
		}
		else
		{
			seg_set_number(*((u32 *)rs485_buf)); // 否则仅显示 RS485 缓冲区里的数
		}
	}
}

void worker(u16 pid) large reentrant // 通用工作进程：根据 timer0_cnt 的某个位闪烁对应 LED
{
    while(1) {
		if((timer0_cnt>>5) & 8) // 使用 timer0_cnt 的位来周期性切换
		{
			SETBIT(led_display_content, pid); // 设置对应 pid 的 LED 位
		}
		else{
			CLEARBIT(led_display_content, pid); // 清除对应 pid 的 LED 位
		}
    }
}

void add_of_player(u8 player,u8 poker) large reentrant // 给指定玩家增加牌分
{
	XDATA float score = (float)poker; // 将牌点转换为浮点分数
	// face cards J/Q/K score as 0.5
	if (poker == 11 || poker == 12 || poker == 13) { // 如果是 J/Q/K
		score = 0.5f; // 人脸牌计0.5分
	}
	if(player == 1){ // 如果是玩家1
		player1 += score; // 累加到 player1
		return; // 返回
	}
	player2 += score; // 否则累加到 player2
}


u8 get_winner() large reentrant // 计算并返回胜者编号（1或2），0 表示平局
{
	if(player1 > 10.5){ // 若玩家1爆点（>10.5）
		return 2; // 玩家1爆点，玩家2获胜
	}
	if(player2 > 10.5){ // 若玩家2爆点
		return 1; // 玩家2爆点，玩家1获胜
	}
	if(player1 > player2){ // 比较分数大小
		return 1; // 玩家1分数更高
	}
	else if(player1 < player2){
		return 2; // 玩家2分数更高
	}
	else{
		return 0; // 平局
	}
}
void server() // 服务器端处理接收的 RS485 数据并更新游戏状态
{
	XDATA u8 usbcom, now_turn, player, poker; // 局部变量：usbcom 数据、当前轮次、玩家、牌
	usbcom = 0x08; // 设置 usbcom 控制字节为0x08（协议相关）	
	usbcom_write(&usbcom,1); // 通过 USB 发送单字节通知
	seg_set_n_at_k(4,5); // 在数码管位置4显示数字5（状态指示）	
	seg_set_float_at_three_seg(player1,0); // 在前三位显示 player1 分数
	seg_set_float_at_three_seg(player2,5); // 在后三位显示 player2 分数（偏移5）
	now_turn = 2-(turn & 0x01); // 计算当前行动方（轮换逻辑）	
	//seg_set_n_at_k(3,now_turn);
	player = rs485_buf[0] & 0x03; // 从 rs485_buf 低两位取玩家编号
	poker = (rs485_buf[0] & 0x3C)>>2; // 从 rs485_buf 中取出牌值（位2-5）
	if(now_turn != player){ // 如果收到的玩家不是当前该出牌者
		SETBIT(led_display_content, 1); // 设置错误指示位
		seg_set_n_at_k(4, 3); // 在数码管位置4显示数字3表示错误或等待
		return; // 退出，不处理此数据
	}
	add_of_player(player, poker); // 将牌分加到对应玩家
	// 标记已处理的 rs485 数据，避免在紧循环中重复处理同一张牌
	rs485_buf[0] = 0; // 清理缓冲区第0字节
	rs485_write(&rs485_buf[0],1); // 通过 RS485 发送清零字节（协议相关）
	gametime = ((gametime/10000)+1)*10000; // 将 gametime 调整到下一个 10000 的边界
	seg_set_float_at_three_seg(player1,0); // 更新显示 player1 分数
	seg_set_float_at_three_seg(player2,5); // 更新显示 player2 分数
	usbcom = 0x0C; // 设置 usbcom 控制字节为0x0C（协议相关）
	usbcom_write(&usbcom,1); // 通过 USB 发送单字节通知
	SETBIT(led_display_content, 0); // 设置显示位0（可能表示处理成功）
	if(player1 > 10.5 || player2 > 10.5){ // 如果任一玩家爆点
		winner = get_winner(); // 计算胜者
		seg_set_n_at_k(4,winner); // 在数码管位置4显示胜者编号
		usbcom_write(&winner,1); // 通过 USB 发送胜者编号
		return; // 结束本次处理
	}
}

void client() // 客户端处理从 USB 接收并根据按键决定是否通过 RS485 发送
{
	XDATA u8 player, poker, usbcom, rs485; // 局部变量：玩家、牌、usbcom 数据、rs485 发送字节
	usbcom = usbcom_buf[0]; // 从 usbcom 缓冲区取第0字节
	player = usbcom & 0x03; // 低两位表示玩家编号
	poker = (usbcom & 0x3C)>>2; // 位2-5表示牌
	seg_set_number_at_a_to_b(poker, 0, 1); // 在数码管的某段显示牌号
	if (character != player){ // 如果当前设备的角色不等于玩家编号
		seg_set_n_at_k(4, 3); // 在数码管位置4显示3（表示非法或非本机操作）
		return; // 返回不处理
	}
	proc_wait_evts(EVT_BTN1_DN | EVT_BTN2_DN); // 等待按钮1或按钮2按下
	seg_set_n_at_k(4, 5); // 在数码管位置4显示5（表示已进入选择阶段）
	if(MY_EVENTS & EVT_BTN1_DN){ // 如果按下按钮1
		rs485_write(&usbcom,1); // 通过 RS485 发送 usbcom 数据（出牌）
		seg_set_n_at_k(4, 6); // 在数码管位置4显示6（表示已发送）
		return; // 返回
	}
	if(MY_EVENTS & EVT_BTN2_DN){
		AI:; // 标签 AI（未使用的跳转标记）
		rs485 = player; // rs485 发送字节为玩家编号（可能表示让牌）
		rs485_write(&rs485,1); // 通过 RS485 发送1字节
		seg_set_n_at_k(4, 7); // 在数码管位置4显示7（表示已放弃或 AI 行为）
		return; // 返回
	}
}

void cs_process()  large reentrant // 主游戏进程或基于角色的分支处理（被作为进程启动）
{
	if (character == 0){ // 如果角色为0（主机/服务器）
		while(1)
		{
			seg_set_n_at_k(3, turn); // 在数码管位置3显示当前轮次
			if(turn == allturn){ // 如果达到总轮数
				winner = get_winner(); // 计算胜者
				seg_set_n_at_k(4,winner); // 显示胜者
				usbcom_write(&winner,1); // 通过 USB 发送胜者信息
				return; // 结束进程
			}
			gametime++; // 增加游戏时间计数
			server(); // 调用 server 处理一次数据
			if(gametime>10000){ // 如果 gametime 超过阈值
				gametime = 0; 	// 重置 gametime
				turn++; // 进入下一轮
			}
		}
	}
	else { // 若不是角色0（客户端）
		while(1)
		{
			proc_wait_evts(EVT_UART1_RECV); // 等待 UART1 接收事件
			//proc_wait_evts(EVT_UART2_RECV);
			seg_set_n_at_k(3,5); // 在数码管位置3显示5（状态指示）
			client(); // 调用 client 处理接收到的数据并等待按键
			seg_set_n_at_k(3,6); // 在数码管位置3显示6（处理完成指示）
		}
	}
}


main() // 程序入口：初始化内核栈、外设、启动进程并进入空循环
{
	//initialize kernel stack and xstack pointer
	SP = kernel_stack; // 设置堆栈指针为内核栈底
	setxbp(kernel_xstack + KERNEL_XSTACKSIZE); // 设置扩展栈指针
	
	//set process stacks and swap stacks owner
	process_stack[0][PROCESS_STACKSIZE-1] = 0; // 设置进程0的栈拥有者标识
	process_stack[1][PROCESS_STACKSIZE-1] = 1; // 设置进程1的栈拥有者标识
	process_stack[2][PROCESS_STACKSIZE-1] = 2; // 设置进程2的栈拥有者标识
	process_stack[3][PROCESS_STACKSIZE-1] = 3; // 设置进程3的栈拥有者标识
	process_stack[4][PROCESS_STACKSIZE-1] = 4; // 设置进程4的栈拥有者标识
	process_stack_swap[0][PROCESS_STACKSIZE-1] = 5; // 设置 swap 栈拥有者标识（备用）
	process_stack_swap[1][PROCESS_STACKSIZE-1] = 6; // 设置 swap 栈拥有者标识（备用）
	process_stack_swap[2][PROCESS_STACKSIZE-1] = 7; // 设置 swap 栈拥有者标识（备用）
	
	//initialize LED pins
	P0M1 &= 0x00; // 配置 P0 模式寄存器 M1 清零（推挽/准双向视 MCU）
	P0M0 |= 0xff; // 配置 P0 模式寄存器 M0 全置1（使能输出）
	P2M1 &= 0xf0; // 配置 P2 M1 高四位保留低四位清零
	P2M0 |= 0x0f; // 配置 P2 M0 低四位置1
	//select LED, set all off
	P23 = 1; // 选择 LED 段（高电平选择）
	P0 = 0; // 关闭 P0 端口输出（熄灭显示）

	//initialize buttons
	buttons_init(); // 初始化按键驱动
	
	//initialize serial ports
	usbcom_init(115200); // 初始化 USB 串口，波特率115200
	rs485_init(115200); // 初始化 RS485，波特率115200

	character = 2; // mode 设置设备角色为2（默认）

	start_process_with_prio((u16)cs_process, 2, 2, 7); // 游戏主进程（暂时注释，不启动）	
		
	//initialize PCA2 interrupt (as syscall interrupt)
	//clear CCF2
	CCON &= ~0x04; // 清除 PCA 模块 CCF2 标志
	//disable PCA2 module and set ECCF2
	CCAPM2 = 1; // 配置 CCAPM2 寄存器（使能/模式位）
	//low priority interrupt
	PPCA = 0; // 设置 PCA 中断为低优先级
	
	//start main timer
	TR0 = 0; 												//stop timer
	TMOD &= 0xF0; 											//timer mode, 16b autoreload
	AUXR &= 0x7F; 											//12T mode
	TL0 = T12RL & 0xff; 								//set reload value 低字节
	TH0 = (T12RL & 0xff00) >> 8; // 设置定时器重载值高字节
	ET0 = EA = 1; 										//set interrupt enable，使能总中断和定时器0中断
	PT0 = 0; 											//set priority to low，将定时器0中断优先级设为低
	TR0 = 1; 											//start timer 启动定时器0
	
	//spin
	while(1); // 主循环挂起，所有工作由进程/中断驱动
}