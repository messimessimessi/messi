#include "random.h" // 引入本文件对应的头文件，声明类型和函数原型

XDATA u32 __rndseed = 0xf2e0062c; // 使用 XDATA 存储的全局32位随机种子，初始化为固定值

u32 rand32() large reentrant // 生成32位随机数的函数，声明为 large reentrant（大内存可重入）
{
    //LCG: (aX+c)%m
    __rndseed = ((__rndseed * 1103515245) + 12345) & 0x7fffffff; // 线性同余生成器（LCG），更新种子并掩码以保持为31位非负值
    return __rndseed; // 返回更新后的随机种子作为随机数
}


void srand() // 用外部时间源为随机数种子设定初始值（不带参数的实现）
{
	XDATA u8 tmp; // 使用 XDATA 存储的临时8位变量
	tmp = ds1302_readbyte(DS1302_SEC); // 从 DS1302 实时时钟读取秒寄存器并赋值给 tmp
	__rndseed = tmp; // 将读取到的秒数作为随机种子的初始值（低位）
	tmp = ds1302_readbyte(DS1302_MIN); // 读取分钟寄存器
	__rndseed += tmp; // 将分钟叠加到种子上，增加熵
	tmp = ds1302_readbyte(DS1302_HR); // 读取小时寄存器
	__rndseed += tmp; // 将小时叠加到种子上，进一步改变初始种子
}
