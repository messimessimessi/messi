#include "events.h" // 包含事件模块的头文件，声明所需的类型、宏和外部变量

XDATA u32 curr_events = 0; // 当前发生的事件位掩码，记录本轮收集到的所有事件
XDATA u8 proc_waiting_evt = 0; // 每位表示对应进程是否处于等待事件的状态（位集合）
XDATA u32 proc_listening_list[8] = {0,0,0,0,0,0,0,0}; // 每个进程监听的事件集合（按位表示）
/*
    Example: process P waiting on event EVT_XXX and EVT_YYY
    proc_waiting_evt.bit[P] = 1;
    proc_listening_list[P] = EVT_XXX | EVT_YYY;
*/ // 示例注释：说明如何设置等待和监听的事件

void dispatch_events(u8 pid) // 分发事件给 pid 指定的进程，如果该进程正在等待且监听的事件发生则唤醒
{
    if(proc_waiting_evt & BIT(pid)) // 如果进程 pid 在等待事件（对应位为1）
    {
        if(proc_listening_list[pid] & curr_events) // 如果该进程监听的事件与当前事件集合有交集
        {
            /*
            process can read this to know which of 
            the listened events is actually occured.
            */ // 保留原英文注释，解释：进程可读取 proc_listening_list 知道发生了哪些被监听的事件
            proc_listening_list[pid] = curr_events;  // 将实际发生的事件写回到进程的监听列表以便进程读取
            CLEARBIT(proc_waiting_evt, pid); // 清除该进程的等待标志，表示已唤醒/不再等待
        }
                else if((proc_listening_list[pid] & EVT_TIMER) && (proc_sleep_countdown[pid]==0)) // 如果进程监听定时器事件且睡眠倒计时为0
                {
                      proc_listening_list[pid] = EVT_TIMER;  // 设置为定时器事件已发生
            CLEARBIT(proc_waiting_evt, pid); // 清除等待标志，唤醒进程
                }
    }
}

void collect_btnevts() // 收集按键相关的事件并设置到 curr_events 中
{
	update_button_state(); // 更新按键状态（上升边沿、下降边沿等）

    if(btnstate_posedge & BTNSTATE_B1) curr_events |= EVT_BTN1_DN; // B1 按键按下（上升沿）事件
    if(btnstate_posedge & BTNSTATE_B2) curr_events |= EVT_BTN2_DN; // B2 按键按下事件
    if(btnstate_posedge & BTNSTATE_B3) curr_events |= EVT_BTN3_DN; // B3 按键按下事件
    if(btnstate_posedge & BTNSTATE_UP)      curr_events |= EVT_NAV_U; // 导航上按下事件
    if(btnstate_posedge & BTNSTATE_DOWN)    curr_events |= EVT_NAV_D; // 导航下按下事件
    if(btnstate_posedge & BTNSTATE_LEFT)    curr_events |= EVT_NAV_L; // 导航左按下事件
    if(btnstate_posedge & BTNSTATE_RIGHT)   curr_events |= EVT_NAV_R; // 导航右按下事件
    if(btnstate_posedge & BTNSTATE_PUSH)    curr_events |= EVT_NAV_PUSH; // 导航推按钮按下事件
    
    if(btnstate_negedge & BTNSTATE_B1) curr_events |= EVT_BTN1_UP; // B1 松开（下降边沿）事件
    if(btnstate_negedge & BTNSTATE_B2) curr_events |= EVT_BTN2_UP; // B2 松开事件
    if(btnstate_negedge & BTNSTATE_B3) curr_events |= EVT_NAV_BTN3_RESET; // B3 松开触发的重置事件（或通用重置处理）
    if(btnstate_negedge & BTNSTATE_UP)      curr_events |= EVT_NAV_BTN3_RESET; // 导航上松开触发重置事件
    if(btnstate_negedge & BTNSTATE_DOWN)    curr_events |= EVT_NAV_BTN3_RESET; // 导航下松开触发重置事件
    if(btnstate_negedge & BTNSTATE_LEFT)    curr_events |= EVT_NAV_BTN3_RESET; // 导航左松开触发重置事件
    if(btnstate_negedge & BTNSTATE_RIGHT)   curr_events |= EVT_NAV_BTN3_RESET; // 导航右松开触发重置事件
    if(btnstate_negedge & BTNSTATE_PUSH)    curr_events |= EVT_NAV_BTN3_RESET; // 导航推按钮松开触发重置事件
}


void collect_uartevts() // 收集串口（UART/RS485/USB）相关事件
{
	if(rs485_evtstate) // 如果 RS485 有事件标志
	{
			rs485_evtstate = 0; // 清除事件标志
			curr_events |= EVT_UART2_RECV; // 将 RS485 接收事件加入当前事件集合
	}
	if(usbcom_evtstate) // 如果 USB 串口有事件标志
	{
		usbcom_evtstate = 0; // 清除 USB 事件标志
		curr_events |= EVT_UART1_RECV; // 将 USB 串口接收事件加入当前事件集合
	}
}


void process_events() // 主事件处理入口：收集并分发事件
{
    curr_events = 0; // 每次处理前清空当前事件集合
    
    collect_btnevts(); // 收集按键事件
    collect_uartevts(); // 收集串口事件

		dispatch_events(0); // 尝试分发事件给进程 0
		dispatch_events(1); // 尝试分发事件给进程 1
		dispatch_events(2); // 尝试分发事件给进程 2
		dispatch_events(3); // 尝试分发事件给进程 3
		dispatch_events(4); // 尝试分发事件给进程 4
		dispatch_events(5); // 尝试分发事件给进程 5
		dispatch_events(6); // 尝试分发事件给进程 6
		dispatch_events(7); // 尝试分发事件给进程 7
}