#include "ds1302.h" // 包含 DS1302 芯片相关定义和函数声明
#include "seg_led.h" // 包含数码管显示或相关工具的定义

void ds1302_writebyte(u8 addr, u8 write)
{
    ds1302_dout(); // 将 DS1302 IO 引脚设置为输出模式

    DS1302_RST = 1; // 拉高 RST 引脚，启动与 DS1302 的通信

    DS1302_IO = 0;  // 将 IO 线置 0，表示接下来发送的是写命令位
    ds1302_clockpulse(); // 产生一个时钟脉冲，使芯片读取当前 IO 状态

    //address
    {
        DS1302_IO = GETBIT(addr,0); // 将地址的第0位（最低位）放到 IO
        ds1302_clockpulse(); // 产生时钟脉冲以移位

        DS1302_IO = GETBIT(addr,1); // 将地址的第1位放到 IO
        ds1302_clockpulse(); // 产生时钟脉冲

        DS1302_IO = GETBIT(addr,2); // 将地址的第2位放到 IO
        ds1302_clockpulse(); // 产生时钟脉冲

        DS1302_IO = GETBIT(addr,3); // 将地址的第3位放到 IO
        ds1302_clockpulse(); // 产生时钟脉冲

        DS1302_IO = GETBIT(addr,4); // 将地址的第4位放到 IO
        ds1302_clockpulse(); // 产生时钟脉冲

        DS1302_IO = GETBIT(addr,5); // 将地址的第5位放到 IO（0->时间寄存器，1->RAM）
        ds1302_clockpulse(); // 产生时钟脉冲
    }

    DS1302_IO = 1; // 设置第7位为1（命令格式中的固定位），准备发送数据字节
    ds1302_clockpulse(); // 产生时钟脉冲以锁存该位

    
    //data
    {
        DS1302_IO = GETBIT(write,0); // 将要写入的数据低位写到 IO
        ds1302_clockpulse(); // 产生时钟脉冲，发送该位

        DS1302_IO = GETBIT(write,1); // 将数据的第1位写到 IO
        ds1302_clockpulse(); // 产生时钟脉冲

        DS1302_IO = GETBIT(write,2); // 将数据的第2位写到 IO
        ds1302_clockpulse(); // 产生时钟脉冲

        DS1302_IO = GETBIT(write,3); // 将数据的第3位写到 IO
        ds1302_clockpulse(); // 产生时钟脉冲

        DS1302_IO = GETBIT(write,4); // 将数据的第4位写到 IO
        ds1302_clockpulse(); // 产生时钟脉冲

        DS1302_IO = GETBIT(write,5); // 将数据的第5位写到 IO
        ds1302_clockpulse(); // 产生时钟脉冲

        DS1302_IO = GETBIT(write,6); // 将数据的第6位写到 IO
        ds1302_clockpulse(); // 产生时钟脉冲

        DS1302_IO = GETBIT(write,7); // 将数据的第7位（最高位）写到 IO
        ds1302_clockpulse(); // 产生时钟脉冲
    }


    //reset pins
    DS1302_SCLK = 0; // 将时钟线拉低，结束时钟信号
    DS1302_IO = 0; // 清空 IO 线路状态
    DS1302_RST = 0; // 拉低 RST，引脚复位，结束通信
}


u8 ds1302_readbyte(u8 addr) 
{
    XDATA u8 read = 0; // 在 XDATA 区域定义一个字节用于存放读取到的数据
		
    ds1302_dout(); // 设置 IO 为输出，以便先发送读取命令位和地址

    DS1302_RST = 1; // 拉高 RST，启动通信

    DS1302_IO = 1;  // 将 IO 置 1，表示接下来发送的是读命令位
    ds1302_clockpulse(); // 发送时钟脉冲以锁存命令位

    //address
    {
        DS1302_IO = GETBIT(addr,0); // 发送地址第0位到 IO
        ds1302_clockpulse(); // 时钟脉冲，移位

        DS1302_IO = GETBIT(addr,1); // 发送地址第1位到 IO
        ds1302_clockpulse(); // 时钟脉冲

        DS1302_IO = GETBIT(addr,2); // 发送地址第2位到 IO
        ds1302_clockpulse(); // 时钟脉冲

        DS1302_IO = GETBIT(addr,3); // 发送地址第3位到 IO
        ds1302_clockpulse(); // 时钟脉冲

        DS1302_IO = GETBIT(addr,4); // 发送地址第4位到 IO
        ds1302_clockpulse(); // 时钟脉冲

        DS1302_IO = GETBIT(addr,5); // 发送地址第5位到 IO（0->时间寄存器，1->RAM）
        ds1302_clockpulse(); // 时钟脉冲
    }

    DS1302_IO = 1; // 发送命令格式中的固定位
    ds1302_clockpulse(); // 时钟脉冲以锁存该位

    ds1302_din(); // 将 IO 配置为输入模式，以便读取数据位
    //data
    {
        WRITEBIT(read, 0, DS1302_IO); // 读取 IO 当前电平写入 read 的第0位
        ds1302_clockpulse(); // 时钟脉冲，移位并准备下一位

        WRITEBIT(read, 1, DS1302_IO); // 读取第1位
        ds1302_clockpulse(); // 时钟脉冲

        WRITEBIT(read, 2, DS1302_IO); // 读取第2位
        ds1302_clockpulse(); // 时钟脉冲

        WRITEBIT(read, 3, DS1302_IO); // 读取第3位
        ds1302_clockpulse(); // 时钟脉冲

        WRITEBIT(read, 4, DS1302_IO); // 读取第4位
        ds1302_clockpulse(); // 时钟脉冲

        WRITEBIT(read, 5, DS1302_IO); // 读取第5位
        ds1302_clockpulse(); // 时钟脉冲

        WRITEBIT(read, 6, DS1302_IO); // 读取第6位
        ds1302_clockpulse(); // 时钟脉冲

        WRITEBIT(read, 7, DS1302_IO); // 读取第7位（最高位）
        ds1302_clockpulse(); // 时钟脉冲
    }

    //reset pins
    DS1302_RST = 0; // 拉低 RST，结束通信
    DS1302_SCLK = 0; // 将时钟线拉低
    DS1302_IO = 0; // 清空 IO 线路
		
		return read; // 返回读取到的字节
}
