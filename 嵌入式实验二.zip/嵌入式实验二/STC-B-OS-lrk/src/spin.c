#include "spin.h"

void spin()
{
	while(1)
	{
	}
}
