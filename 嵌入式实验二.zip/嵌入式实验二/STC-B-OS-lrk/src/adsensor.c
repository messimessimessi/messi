#include "adsensor.h" // 包含ADC传感器相关的头文件，声明宏和函数

XDATA u8 adc_initialized = 0; // 使用XDATA定义的8位变量，标记ADC是否已初始化（0表示未初始化）
void adc_init() // ADC初始化函数
{ // 函数开始
    if(adc_initialized) // 如果已初始化
        return; // 直接返回，避免重复初始化

    /*
    Initalize ADC: // 初始化ADC说明
        P1.2 for HALL sensor // P1.2 用于霍尔传感器
        P1.3 for Temperature sensor // P1.3 用于温度传感器
        P1.4 for Light sensor // P1.4 用于光照传感器
        P1.7 for Button3 and Navigation Button // P1.7 用于按钮3和导航按钮
    */
    P1ASF = ADC_P12 | ADC_P13 | ADC_P14 | ADC_P17; // 将P1.2、P1.3、P1.4、P1.7配置为模拟输入（ADC通道）

    ADC_CONTR |= 0x80; // Power On：置位ADC电源位，打开ADC模块电源
    ADC_CONTR = (ADC_CONTR & ~ADC_90T) | ADC_90T; // Speed select：设置ADC转换速度（选择ADC_90T）
    PCON2 &= ~(1<<5); // result byte order: high->ADC_RES：清除PCON2的第5位，设置结果字节顺序，使高字节放在ADC_RES
    EADC = 0; // use polling, no interrupt：禁止ADC中断，使用轮询方式读取结果

    adc_initialized = 1; // 标记ADC已完成初始化
} // adc_init结束

u8 adc_read(u8 channel) // 从指定ADC通道读取8位结果
{ // 函数开始
    XDATA u8 timeout; // 超时计数变量，使用XDATA区域存储
	ADC_RES = 0; // 清空结果寄存器，准备新的转换

	ADC_CONTR = (ADC_CONTR & 0xe0) | ADC_START | channel; // select channel：选择通道并启动ADC转换
	NOP(4); // 小延时，确保启动位和通道设置稳定

    // poll：轮询等待转换完成
	for(timeout=0; timeout<250; timeout++)	 // 带超时的轮询循环，防止死循环
	{
		if(ADC_CONTR & ADC_FLAG) // 如果转换完成标志被置位
		{
			ADC_CONTR &= ~ADC_FLAG; // 清除转换完成标志
			return ADC_RES; // 返回ADC结果（通常高字节在ADC_RES）
		}
	}

    	return 0; // 超时或未完成时返回0
} // adc_read结束