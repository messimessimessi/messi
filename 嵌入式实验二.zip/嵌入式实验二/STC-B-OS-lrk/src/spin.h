#ifndef _SPIN_H_
#define _SPIN_H_
#include "global.h"
void spin();

#endif