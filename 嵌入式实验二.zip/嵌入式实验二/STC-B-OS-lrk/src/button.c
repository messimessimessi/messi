#include "button.h" // 包含按钮相关的头文件，声明宏、函数和变量类型

XDATA u8 __nav_btn3_state = 0xff; // 存放导航和按钮3的ADC/去抖状态初始值，0xff表示未初始化或默认高电平
XDATA u8 btnstate_posedge   =0; // 记录按键上升沿（按下）的位掩码
XDATA u8 btnstate_negedge   =0; // 记录按键下降沿（释放）的位掩码
XDATA u8 last_btn_states[BTN_DENOISE_LEVEL]; // 环形缓存，保存最近多次采样的按键状态以去抖

void buttons_init()
{
    //Initialize ADC for Nav and Button3
    adc_init(); // 初始化ADC，用于读取导航与按钮3的模拟/电阻值

    //Set Button1 and Button2 pin to Weak Pullup (M1 = 0, M0 = 0)
    P3M1 &= 0xF3;   // 1111 0011 清除P3的相应位，使按键1/2为弱上拉模式
    P3M0 &= 0xF3;   // 1111 0011 同上，设置P3端口模式位为弱上拉

    //Set P17 to Weak Pullup (M1 = 0, M0 = 0)
    //P17 Pullup -> Key3 -> Nav Button(different resistance) -> GND
    P1M1 &= 0x7F; // 0111 1111 清除P1的相应位，设置P17为弱上拉
    P1M0 &= 0x7F; // 0111 1111 同上，配置P1端口模式为弱上拉
}

void update_button_state()
{
		XDATA u8 i; //Only use this function in timer0 isr. this variable prevents reentrancy.
		// 局部计数器，仅在定时器0中断中调用该函数，防止重入导致数据竞争
		
		btnstate_posedge = btnstate_negedge = 0; // 清除上/下沿标志，为本次采样准备
		
		//rotate previous button states. older one replaced by newer one.
		for(i = BTN_DENOISE_LEVEL-1; i>=1; i--)
			last_btn_states[i] = last_btn_states[i-1];	// 将历史状态向后移动一位，淘汰最旧的一条
		
		//update current button state, and cauculate bit flags
    update_nav_btn3_state(); // 更新导航和按钮3的状态（ADC读数转换为按键标志）
		last_btn_states[0]  = 0; // 清空最新采样位域
    last_btn_states[0] |= BUTTON1       ?BTNSTATE_B1    :0; // 如果BUTTON1为真则设置B1位
    last_btn_states[0] |= BUTTON2       ?BTNSTATE_B2    :0; // 如果BUTTON2为真则设置B2位
    last_btn_states[0] |= IS_BTN3_PUSH  ?BTNSTATE_B3    :0; // 如果按钮3被按下则设置B3位
    last_btn_states[0] |= IS_NAV_LEFT   ?BTNSTATE_LEFT  :0; // 导航左按下则设置LEFT位
    last_btn_states[0] |= IS_NAV_RIGHT  ?BTNSTATE_RIGHT :0; // 导航右按下则设置RIGHT位
    last_btn_states[0] |= IS_NAV_UP     ?BTNSTATE_UP    :0; // 导航上按下则设置UP位
    last_btn_states[0] |= IS_NAV_DOWN   ?BTNSTATE_DOWN  :0; // 导航下按下则设置DOWN位
    last_btn_states[0] |= IS_NAV_PUSH  ?BTNSTATE_PUSH  :0; // 导航按下（中心键）则设置PUSH位

		//check new state hold
		for(i=0;i<BTN_DENOISE_LEVEL-1;i++)
		{
				if(last_btn_states[i] != last_btn_states[0])
					return; // 如果任何历史采样与当前最新采样不同，则认为按键尚未稳定，直接返回
		}
		
		//different from old states, and currently set -> posedge
		btnstate_posedge = (last_btn_states[0] ^ last_btn_states[BTN_DENOISE_LEVEL-1]) & (last_btn_states[0]);    // 与最旧样本比较，若有变化且当前为按下则为上升沿

		//different from old states, and previously set -> negedge
		btnstate_negedge = (last_btn_states[0] ^ last_btn_states[BTN_DENOISE_LEVEL-1]) & (last_btn_states[BTN_DENOISE_LEVEL-1]); // 若有变化且最旧样本为按下则为下降沿
}